var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["fba13272-cb2f-4f66-ae6a-fe36543b31be","b8089e4f-408f-4029-8f41-1ecfd9284fc2","6404cb57-401e-4699-a832-455ed042bd44","53e732c2-0b36-45ff-bd91-d76938d1551f","9ac68853-e1a8-4c95-86d2-e48b8b957611","d9641751-cc0b-4d9d-b669-8a1fc947faaf","04d61313-7e7b-4b32-a26b-57d9919fbaa4","5285cf55-a138-440f-841d-7e40ffc35d35","30a047bc-ff27-4708-826e-0c7e91001b17"],"propsByKey":{"fba13272-cb2f-4f66-ae6a-fe36543b31be":{"name":"space_1","sourceUrl":"assets/api/v1/animation-library/gamelab/qoFFPgWiydir6HZwldQy.Fmh8NmNhTI9/category_backgrounds/background_space.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"qoFFPgWiydir6HZwldQy.Fmh8NmNhTI9","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/qoFFPgWiydir6HZwldQy.Fmh8NmNhTI9/category_backgrounds/background_space.png"},"b8089e4f-408f-4029-8f41-1ecfd9284fc2":{"name":"spacebattle_01_1","sourceUrl":null,"frameSize":{"x":30,"y":23},"frameCount":1,"looping":true,"frameDelay":12,"version":"KiFDhIrMEtakYfml7jqz_.Qrit92FifF","categories":["retro"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":30,"y":23},"rootRelativePath":"assets/b8089e4f-408f-4029-8f41-1ecfd9284fc2.png"},"6404cb57-401e-4699-a832-455ed042bd44":{"name":"inimigo1","sourceUrl":null,"frameSize":{"x":20,"y":22},"frameCount":1,"looping":true,"frameDelay":12,"version":"ksjbUefJxzO3BrA7KLKL15uvXSzqTmwh","categories":["retro"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":20,"y":22},"rootRelativePath":"assets/6404cb57-401e-4699-a832-455ed042bd44.png"},"53e732c2-0b36-45ff-bd91-d76938d1551f":{"name":"inimigo2","sourceUrl":null,"frameSize":{"x":20,"y":22},"frameCount":1,"looping":true,"frameDelay":12,"version":"c7KTUWvw5WNVztny6vwsssKnE2xt7RWO","categories":["retro"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":20,"y":22},"rootRelativePath":"assets/53e732c2-0b36-45ff-bd91-d76938d1551f.png"},"9ac68853-e1a8-4c95-86d2-e48b8b957611":{"name":"inimigo3","sourceUrl":null,"frameSize":{"x":20,"y":20},"frameCount":1,"looping":true,"frameDelay":12,"version":"vr5PRtR7XaFnrkW4qAisRBjKcFFUjMsm","categories":["retro"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":20,"y":20},"rootRelativePath":"assets/9ac68853-e1a8-4c95-86d2-e48b8b957611.png"},"d9641751-cc0b-4d9d-b669-8a1fc947faaf":{"name":"inimigo4","sourceUrl":null,"frameSize":{"x":20,"y":20},"frameCount":1,"looping":true,"frameDelay":12,"version":"cJrL32xQP08yjQyJhvtXFfhaf2DxfgvT","categories":["retro"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":20,"y":20},"rootRelativePath":"assets/d9641751-cc0b-4d9d-b669-8a1fc947faaf.png"},"04d61313-7e7b-4b32-a26b-57d9919fbaa4":{"name":"inimigo5","sourceUrl":null,"frameSize":{"x":20,"y":22},"frameCount":1,"looping":true,"frameDelay":12,"version":"tG_BdtXfxltX_xU2qlTZZkw8j0SYDErU","categories":["retro"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":20,"y":22},"rootRelativePath":"assets/04d61313-7e7b-4b32-a26b-57d9919fbaa4.png"},"5285cf55-a138-440f-841d-7e40ffc35d35":{"name":"inimigo6","sourceUrl":null,"frameSize":{"x":20,"y":22},"frameCount":1,"looping":true,"frameDelay":12,"version":"N1DROr4H3rHhYcA375MSxKZO2V1RIrWv","categories":["retro"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":20,"y":22},"rootRelativePath":"assets/5285cf55-a138-440f-841d-7e40ffc35d35.png"},"30a047bc-ff27-4708-826e-0c7e91001b17":{"name":"textGameOver_1","sourceUrl":null,"frameSize":{"x":200,"y":40},"frameCount":1,"looping":true,"frameDelay":12,"version":"lL3Id_93PN9yIQ9yMoeeOVjRDZtnp.uV","categories":["video_games"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":200,"y":40},"rootRelativePath":"assets/30a047bc-ff27-4708-826e-0c7e91001b17.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var a = createSprite(10,15,1000,50)
a.shapeColor ="red"

var plano_de_fundo = createSprite(200,200,30,30);
plano_de_fundo.setAnimation("space_1");

var nave = createSprite(200,390,20,20);
nave.setAnimation("spacebattle_01_1");

var inimigo1 = createSprite(385,330,20,20);
inimigo1.setAnimation("inimigo1");
inimigo1.velocityX  =8;
  
var inimigo2 = createSprite(15,280,20,20);
inimigo2.setAnimation("inimigo2");
inimigo2.velocityX=8;

var inimigo3 = createSprite(385,230,20,20);
inimigo3.setAnimation("inimigo3");
inimigo3.velocityX=8;

var inimigo4 = createSprite(15,180,20,20);
inimigo4.setAnimation("inimigo4");
inimigo4.velocityX=8;

var inimigo5 = createSprite(385,130,20,20);
inimigo5.setAnimation("inimigo5");
inimigo5.velocityX=8;

var inimigo6 = createSprite(15,80,20,20);
inimigo6.setAnimation("inimigo6");
inimigo6.velocityX=8;


background("white");


function draw() {
  drawSprites();
  
createEdgeSprites();
nave.bounceOff(edges);
inimigo1.bounceOff(edges);
inimigo2.bounceOff(edges);
inimigo3.bounceOff(edges);
inimigo4.bounceOff(edges);
inimigo5.bounceOff(edges);
inimigo6.bounceOff(edges);

if(keyDown(UP_ARROW)){
  nave.y=nave.y -5;
}

 
 if(keyDown(DOWN_ARROW)){
   nave.y=nave.y +5;
 }
 
 if(keyDown(LEFT_ARROW)){
   nave.x=nave.x-5;
 }
 
 if(keyDown(RIGHT_ARROW)){
   nave.x=nave.x+5;
 }
  
if(inimigo1.isTouching(nave)||inimigo2.isTouching(nave)||inimigo3.isTouching(nave)||inimigo4.isTouching(nave)||inimigo5.isTouching(nave)||inimigo6.isTouching(nave)){
  fill("textGameOver_1");
  textSize(30);
  fill("red");
  text("voçê perdeu",100,200);
  inimigo1.setVelocity(0,0);
  inimigo2.setVelocity(0,0);
  inimigo3.setVelocity(0,0);
  inimigo4.setVelocity(0,0);
  inimigo5.setVelocity(0,0);
  inimigo6.setVelocity(0,0);
  nave.velocity =0;
}

  
  


  //ganhar o jogo 
if (nave.isTouching(a)){
textSize(30);
fill("red");
text("parabéns você ganhou!!!",50,200);
inimigo1.setVelocity(0,0);
  inimigo2.setVelocity(0,0);
  inimigo3.setVelocity(0,0);
  inimigo4.setVelocity(0,0);
  inimigo5.setVelocity(0,0);
  inimigo6.setVelocity(0,0);
  nave.velocity =0;
  
 
  
  
}
}
// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
